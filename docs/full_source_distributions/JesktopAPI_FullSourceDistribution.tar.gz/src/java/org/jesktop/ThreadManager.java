package org.jesktop;

public interface ThreadManager {
}
