This jar is both standalon executable ...

   java -jar jesktop-frimble-demoapp2.jar
   
... and installable into Jesktop as a hosted application.




- Paul H