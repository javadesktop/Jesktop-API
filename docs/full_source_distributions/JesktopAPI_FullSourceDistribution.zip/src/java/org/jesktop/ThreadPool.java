package org.jesktop;

public interface ThreadPool {
    void execute(Runnable runnable);
}
